# VIDAI — AI Short Video Generator
Made by Yankee

## How to Deploy on Vercel (Free)

### Step 1 — Upload to GitHub
1. Go to github.com and create a free account
2. Click "New repository", name it `vidai`, click "Create repository"
3. Upload all these files to the repository

### Step 2 — Deploy on Vercel
1. Go to vercel.com and sign up with your GitHub account
2. Click "Add New Project"
3. Select your `vidai` repository
4. Click "Deploy" — Vercel does the rest automatically!

### Step 3 — Get your link
After deploying you will get a free link like:
👉 https://vidai.vercel.app

Share this link on:
- WhatsApp groups
- TikTok bio
- Facebook
- YouTube description

### Payment
Customers send UGX 5,000 to Airtel Money: 0753 864663 (Nsereko Isaac)
Then enter their transaction ID to unlock the app.

---
Built with React + Next.js + Claude AI
